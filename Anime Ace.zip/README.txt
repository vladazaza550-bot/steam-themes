This font is © 2006 Nate Piekos.  All Rights Reserved.  
Created for Blambot Fonts

This font is freeware for independent comic book creation and 
non-profit use ONLY. ( This excludes use by "mainstream" publishers,
(Marvel, DC, Dark Horse, Oni, Image, SLG, Top Cow, Crossgen and their 
subsidiaries) without a license fee. Use by a "mainstream" publisher 
(or it's employee), and use for commercial non-comic book production 
(eg. magazine ads, merchandise lables etc.) incurs a license fee 
be paid to the designer, Nate Piekos. 
This font may not be redistributed without the author's permission and
never with this text file missing from the .zip, .sit or .hqx.

Blambot/Nate Piekos makes no guarantees about these font files,
 the completeness of character sets, or safety of these files on your
computer.  By installing these fonts on your system, you prove that 
you have read and understand the above.

If you have any questions, visit http://www.blambot.com/license.shtml

For more free and original fonts visit Blambot.
www.blambot.com

Nate Piekos
studio@blambot.com
